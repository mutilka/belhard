
console.log("Привет!");